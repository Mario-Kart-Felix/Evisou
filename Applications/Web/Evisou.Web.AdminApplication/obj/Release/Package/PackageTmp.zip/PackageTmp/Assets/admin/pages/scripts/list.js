﻿[
    {
        "id": 0, 
        "name": "北京",
        "code": "001",
        "child": [
            {
                "id": 0, 
                "name": "东城区",
                "child": []
            },
            {
                "id": 1,
                "name": "西城区",
                "child": []
            },
            {
                "id": 2,
                "name": "崇文区",
                "child": []
            },
            {
                "id": 3,
                "name": "宣武区",
                "child": []
            },
            {
                "id": 4, 
                "name": "朝阳区",
                "child": []
            },
            {
                "id": 5,
                "name": "丰台区",
                "child": []
            }
        ]
    },
    {
        "id": 1, 
        "name": "广西",
        "code": "002",
        "child": [
            {
                "id": 0, 
                "name": "南宁",
                "child": [
                    {"value": "兴宁区"},
                    {"value": "青秀区"},
                    {"value": "江南区"},
                    {"value": "西乡塘区"},
                    {"value": "良庆区"},
                    {"value": "邕宁区"},
                    {"value": "武鸣县"},
                    {"value": "隆安县"}
                ]
            },
            {
                "id": 1,
                "name": "柳州",
                "child": [
                    {"value": "城中区"},
                    {"value": "鱼峰区"},
                    {"value": "柳南区"},
                    {"value": "柳北区"}
                ]
            },
            {
                "id": 2,
                "name": "桂林",
                "child": [
                    {"value": "秀峰区"},
                    {"value": "叠彩区"},
                    {"value": "象山区"}
                ]
            },
            {
                "id": 3,
                "name": "百色",
                "child": [
                    {"value": "右江区"},
                    {"value": "平果县"},
                    {"value": "田阳县"},
                    {"value": "田东县"},                       
                    {"value": "德保县"}
                ]
            }
        ]
    },
    {
        "id": 2, 
        "name": "广东",
        "code": "003",
        "child": [
            {
                "id": 0, 
                "name": "广州",
                "child": [
                    {"value": "天河区"},
                    {"value": "白云区"},
                    {"value": "黄埔区"}
                ]
            },
            {
                "id": 1,
                "name": "深圳",
                "child": [
                    {"value": "宝安区"},
                    {"value": "南山区"},
                    {"value": "福田区"}
                ]
            },
            {
                "id": 2,
                "name": "珠海",
                "child": []
            }
        ]
    }
]